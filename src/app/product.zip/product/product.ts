export interface IProduct {
    productId: number;
    productName: string;
    productCode: string;
    releaseDate: string;
    price: number;
    description: string;
    starRating: number;
    imageUrl: string;
}

export interface ICategory {
    categoryId: number;
    categoryName: string;
    products : [string],
    subCategories : [string]
}
export interface ISubCategory {
    subCategoryId: number;
    subCategoryName: string;
    products : [string],
    subCategories : [string]
}

export interface IFormFile {

        name : string
        fileName : string
    }